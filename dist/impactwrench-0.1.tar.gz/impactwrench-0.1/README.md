# impactwrench

ImpactWrench is a Python CLI application for LC-MS and LC-MS/MS data analysis 

## Basic setup

Install the requirements:
```
$ pip install -r requirements.txt
```

Run the application:
```
$ python -m impactwrench --help
```

To run the tests:
```
    $ pytest
```
